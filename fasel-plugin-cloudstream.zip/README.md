# FaselHDX Plugin for CloudStream

This plugin allows streaming movies from faselhdxwatch.top in CloudStream.